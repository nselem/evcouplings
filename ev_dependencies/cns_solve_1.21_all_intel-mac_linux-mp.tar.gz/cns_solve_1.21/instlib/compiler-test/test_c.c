#include <stdio.h>
int main(void) { printf("Hello_C_world\n"); return 0; }
